﻿export default function DashboardPage(){

    return(

        <div
            style={{
                color:"white",
                fontSize:32,
                fontWeight:700,
                padding:40
            }}
        >
            DashboardPage
        </div>

    );

}
