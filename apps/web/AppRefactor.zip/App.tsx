import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  enterpriseApi,
  type EnterpriseCalendarItem,
  type EnterpriseDashboard,
  type EnterprisePlatform,
  type EnterpriseProject,
  type EnterprisePrompt,
  type EnterpriseScript,
  type ProjectStatus,
  type ScriptStatus,
} from "./enterprise-api";

type View =
  | "dashboard"
  | "projects"
  | "scripts"
  | "calendar"
  | "prompts";

const emptyDashboard: EnterpriseDashboard = {
  projects: [],
  scripts: [],
  calendar: [],
  prompts: [],
  metrics: {
    projects: 0,
    activeProjects: 0,
    scripts: 0,
    scheduledContent: 0,
    prompts: 0,
  },
  system: {
    projectEngine: "loading",
    scriptEngine: "loading",
    calendarEngine: "loading",
    promptEngine: "loading",
    storage: "loading",
  },
};

const statusLabels: Record<ProjectStatus, string> = {
  planning: "تخطيط",
  active: "نشط",
  paused: "متوقف مؤقتًا",
  completed: "مكتمل",
};

const scriptStatusLabels: Record<ScriptStatus, string> = {
  draft: "مسودة",
  review: "مراجعة",
  approved: "معتمد",
  production: "إنتاج",
};

const platformLabels: Record<EnterprisePlatform, string> = {
  YouTube: "YouTube",
  TikTok: "TikTok",
  Both: "YouTube + TikTok",
};

function App() {
  const [view, setView] = useState<View>("dashboard");
  const [dashboard, setDashboard] =
    useState<EnterpriseDashboard>(emptyDashboard);
  const [connected, setConnected] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const [health, data] = await Promise.all([
        enterpriseApi.health(),
        enterpriseApi.dashboard(),
      ]);

      setConnected(
        Boolean(health.success) &&
          health.status === "operational",
      );
      setDashboard(data);
    } catch (currentError) {
      setConnected(false);
      setError(
        currentError instanceof Error
          ? currentError.message
          : "تعذر الاتصال بالخادم.",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  const runAction = async (
    action: () => Promise<unknown>,
    successMessage: string,
  ) => {
    setBusy(true);
    setError("");
    setMessage("");

    try {
      await action();
      setMessage(successMessage);
      await loadDashboard();
    } catch (currentError) {
      setError(
        currentError instanceof Error
          ? currentError.message
          : "حدث خطأ غير متوقع.",
      );
    } finally {
      setBusy(false);
    }
  };

  const createProject = async () => {
    const name = window.prompt("اسم المشروع:");

    if (!name?.trim()) {
      return;
    }

    const description =
      window.prompt("وصف المشروع:")?.trim() ?? "";

    const platform = selectPlatform();

    if (!platform) {
      return;
    }

    await runAction(
      () =>
        enterpriseApi.createProject({
          name: name.trim(),
          description,
          platform,
        }),
      "تم إنشاء المشروع بنجاح.",
    );
  };

  const createScript = async () => {
    if (dashboard.projects.length === 0) {
      setError("أنشئ مشروعًا أولًا قبل إضافة السكربت.");
      return;
    }

    const project = selectProject(dashboard.projects);

    if (!project) {
      return;
    }

    const title = window.prompt("عنوان السكربت:");

    if (!title?.trim()) {
      return;
    }

    const content =
      window.prompt(
        "محتوى السكربت الأولي:",
        "اكتب محتوى السكربت هنا...",
      ) ?? "";

    await runAction(
      () =>
        enterpriseApi.createScript({
          projectId: project.id,
          title: title.trim(),
          content,
        }),
      "تم إنشاء السكربت بنجاح.",
    );
  };

  const scheduleContent = async () => {
    if (dashboard.projects.length === 0) {
      setError("أنشئ مشروعًا أولًا قبل جدولة المحتوى.");
      return;
    }

    const project = selectProject(dashboard.projects);

    if (!project) {
      return;
    }

    const title = window.prompt("عنوان المحتوى المجدول:");

    if (!title?.trim()) {
      return;
    }

    const suggestedDate = new Date(
      Date.now() + 24 * 60 * 60 * 1000,
    )
      .toISOString()
      .slice(0, 16);

    const dateInput = window.prompt(
      "موعد النشر بصيغة YYYY-MM-DDTHH:mm",
      suggestedDate,
    );

    if (!dateInput || Number.isNaN(Date.parse(dateInput))) {
      setError("موعد النشر غير صالح.");
      return;
    }

    const platform = selectPlatform();

    if (!platform) {
      return;
    }

    await runAction(
      () =>
        enterpriseApi.scheduleContent({
          projectId: project.id,
          title: title.trim(),
          scheduledAt: new Date(dateInput).toISOString(),
          platform,
        }),
      "تمت جدولة المحتوى بنجاح.",
    );
  };

  const createPrompt = async () => {
    const name = window.prompt("اسم القالب الذكي:");

    if (!name?.trim()) {
      return;
    }

    const purpose =
      window.prompt("الغرض من القالب:")?.trim() ?? "";

    const prompt = window.prompt("نص القالب:");

    if (!prompt?.trim()) {
      return;
    }

    await runAction(
      () =>
        enterpriseApi.createPrompt({
          name: name.trim(),
          purpose,
          prompt: prompt.trim(),
        }),
      "تم حفظ القالب الذكي بنجاح.",
    );
  };

  const changeProjectStatus = async (
    project: EnterpriseProject,
  ) => {
    const value = window.prompt(
      [
        "اختر حالة المشروع:",
        "planning",
        "active",
        "paused",
        "completed",
      ].join("\n"),
      project.status,
    );

    if (
      value !== "planning" &&
      value !== "active" &&
      value !== "paused" &&
      value !== "completed"
    ) {
      return;
    }

    await runAction(
      () =>
        enterpriseApi.updateProjectStatus(
          project.id,
          value,
        ),
      "تم تحديث حالة المشروع.",
    );
  };

  const deleteProject = async (
    project: EnterpriseProject,
  ) => {
    const confirmed = window.confirm(
      `سيتم حذف المشروع "${project.name}" وجميع السكربتات والمواعيد التابعة له. هل تريد المتابعة؟`,
    );

    if (!confirmed) {
      return;
    }

    await runAction(
      () => enterpriseApi.deleteProject(project.id),
      "تم حذف المشروع.",
    );
  };

  const changeScriptStatus = async (
    script: EnterpriseScript,
  ) => {
    const value = window.prompt(
      [
        "اختر حالة السكربت:",
        "draft",
        "review",
        "approved",
        "production",
      ].join("\n"),
      script.status,
    );

    if (
      value !== "draft" &&
      value !== "review" &&
      value !== "approved" &&
      value !== "production"
    ) {
      return;
    }

    await runAction(
      () =>
        enterpriseApi.updateScript(script.id, {
          status: value,
        }),
      "تم تحديث حالة السكربت.",
    );
  };

  const editScript = async (
    script: EnterpriseScript,
  ) => {
    const title = window.prompt(
      "عنوان السكربت:",
      script.title,
    );

    if (!title?.trim()) {
      return;
    }

    const content = window.prompt(
      "محتوى السكربت:",
      script.content,
    );

    if (content === null) {
      return;
    }

    await runAction(
      () =>
        enterpriseApi.updateScript(script.id, {
          title: title.trim(),
          content,
        }),
      "تم حفظ تعديلات السكربت.",
    );
  };

  const currentTitle = useMemo(() => {
    const titles: Record<View, string> = {
      dashboard: "مركز قيادة المحتوى",
      projects: "إدارة المشاريع",
      scripts: "محرر السكربتات",
      calendar: "تقويم المحتوى",
      prompts: "مكتبة القوالب الذكية",
    };

    return titles[view];
  }, [view]);

  return (
    <div style={styles.app} dir="rtl">
      <aside style={styles.sidebar}>
        <div style={styles.brand}>
          <div style={styles.logo}>C</div>
          <div>
            <strong style={styles.brandName}>CreatorOS</strong>
            <div style={styles.brandSubtitle}>
              AI MEDIA OPERATING SYSTEM
            </div>
          </div>
        </div>

        <nav style={styles.nav}>
          <NavButton
            active={view === "dashboard"}
            icon="⌂"
            label="لوحة التحكم"
            onClick={() => setView("dashboard")}
          />
          <NavButton
            active={view === "projects"}
            icon="▦"
            label="المشاريع"
            onClick={() => setView("projects")}
          />
          <NavButton
            active={view === "scripts"}
            icon="✎"
            label="محرر السكربت"
            onClick={() => setView("scripts")}
          />
          <NavButton
            active={view === "calendar"}
            icon="▣"
            label="تقويم المحتوى"
            onClick={() => setView("calendar")}
          />
          <NavButton
            active={view === "prompts"}
            icon="✦"
            label="القوالب الذكية"
            onClick={() => setView("prompts")}
          />
        </nav>

        <div style={styles.connectionBox}>
          <div
            style={{
              ...styles.connectionDot,
              background: connected ? "#42e8a1" : "#ff5f74",
            }}
          />
          <div>
            <strong>
              {connected
                ? "Backend API متصل"
                : "Backend API غير متصل"}
            </strong>
            <div style={styles.mutedSmall}>
              البيانات محفوظة في الخادم
            </div>
          </div>
        </div>
      </aside>

      <main style={styles.main}>
        <header style={styles.header}>
          <div>
            <div style={styles.eyebrow}>
              CREATOROS ENTERPRISE
            </div>
            <h1 style={styles.title}>{currentTitle}</h1>
            <p style={styles.subtitle}>
              منظومة تشغيل وإدارة وإنتاج المحتوى بالذكاء
              الاصطناعي.
            </p>
          </div>

          <button
            style={styles.refreshButton}
            disabled={loading || busy}
            onClick={() => void loadDashboard()}
          >
            ↻ تحديث البيانات
          </button>
        </header>

        {message && (
          <div style={styles.successMessage}>{message}</div>
        )}

        {error && (
          <div style={styles.errorMessage}>{error}</div>
        )}

        {loading ? (
          <div style={styles.loading}>
            جارٍ تحميل CreatorOS Enterprise...
          </div>
        ) : (
          <>
            {view === "dashboard" && (
              <DashboardView
                dashboard={dashboard}
                connected={connected}
                busy={busy}
                onCreateProject={createProject}
                onCreateScript={createScript}
                onSchedule={scheduleContent}
                onCreatePrompt={createPrompt}
              />
            )}

            {view === "projects" && (
              <ProjectsView
                projects={dashboard.projects}
                busy={busy}
                onCreate={createProject}
                onStatus={changeProjectStatus}
                onDelete={deleteProject}
              />
            )}

            {view === "scripts" && (
              <ScriptsView
                scripts={dashboard.scripts}
                projects={dashboard.projects}
                busy={busy}
                onCreate={createScript}
                onEdit={editScript}
                onStatus={changeScriptStatus}
              />
            )}

            {view === "calendar" && (
              <CalendarView
                items={dashboard.calendar}
                projects={dashboard.projects}
                busy={busy}
                onCreate={scheduleContent}
              />
            )}

            {view === "prompts" && (
              <PromptsView
                prompts={dashboard.prompts}
                busy={busy}
                onCreate={createPrompt}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}

function DashboardView(props: {
  dashboard: EnterpriseDashboard;
  connected: boolean;
  busy: boolean;
  onCreateProject: () => Promise<void>;
  onCreateScript: () => Promise<void>;
  onSchedule: () => Promise<void>;
  onCreatePrompt: () => Promise<void>;
}) {
  const {
    dashboard,
    connected,
    busy,
    onCreateProject,
    onCreateScript,
    onSchedule,
    onCreatePrompt,
  } = props;

  return (
    <>
      <section style={styles.metricsGrid}>
        <MetricCard
          icon="▦"
          label="المشاريع"
          value={dashboard.metrics.projects}
          note={`${dashboard.metrics.activeProjects} مشروع نشط`}
        />
        <MetricCard
          icon="✎"
          label="السكربتات"
          value={dashboard.metrics.scripts}
          note="محتوى محفوظ في الخادم"
        />
        <MetricCard
          icon="▣"
          label="المحتوى المجدول"
          value={dashboard.metrics.scheduledContent}
          note="عناصر تقويم الإنتاج"
        />
        <MetricCard
          icon="✦"
          label="القوالب الذكية"
          value={dashboard.metrics.prompts}
          note="قوالب الذكاء الاصطناعي"
        />
      </section>

      <section style={styles.twoColumns}>
        <div style={styles.panel}>
          <div style={styles.panelHeader}>
            <div>
              <div style={styles.eyebrow}>QUICK ACTIONS</div>
              <h2 style={styles.panelTitle}>مركز العمليات</h2>
            </div>
          </div>

          <div style={styles.actionsGrid}>
            <ActionButton
              icon="＋"
              title="إنشاء مشروع"
              description="إضافة مشروع محتوى جديد"
              disabled={busy}
              onClick={() => void onCreateProject()}
            />
            <ActionButton
              icon="✎"
              title="إنشاء سكربت"
              description="إضافة سكربت إلى أحد المشاريع"
              disabled={busy}
              onClick={() => void onCreateScript()}
            />
            <ActionButton
              icon="▣"
              title="جدولة محتوى"
              description="تحديد موعد نشر جديد"
              disabled={busy}
              onClick={() => void onSchedule()}
            />
            <ActionButton
              icon="✦"
              title="إضافة قالب ذكي"
              description="حفظ أمر للذكاء الاصطناعي"
              disabled={busy}
              onClick={() => void onCreatePrompt()}
            />
          </div>
        </div>

        <div style={styles.panel}>
          <div style={styles.eyebrow}>LIVE SYSTEM</div>
          <h2 style={styles.panelTitle}>حالة النظام</h2>

          <SystemRow
            label="Backend API"
            value={connected ? "متصل" : "غير متصل"}
          />
          <SystemRow
            label="محرك المشاريع"
            value={dashboard.system.projectEngine}
          />
          <SystemRow
            label="محرك السكربت"
            value={dashboard.system.scriptEngine}
          />
          <SystemRow
            label="محرك التقويم"
            value={dashboard.system.calendarEngine}
          />
          <SystemRow
            label="التخزين"
            value={dashboard.system.storage}
          />
        </div>
      </section>

      <section style={styles.panel}>
        <div style={styles.panelHeader}>
          <div>
            <div style={styles.eyebrow}>
              PRODUCTION WORKSPACE
            </div>
            <h2 style={styles.panelTitle}>
              أحدث المشاريع والسكربتات
            </h2>
          </div>
        </div>

        <div style={styles.workspaceGrid}>
          <div>
            <h3 style={styles.sectionTitle}>المشاريع</h3>
            {dashboard.projects.length === 0 ? (
              <EmptyState text="لا توجد مشاريع حتى الآن." />
            ) : (
              dashboard.projects.slice(0, 4).map((project) => (
                <CompactItem
                  key={project.id}
                  title={project.name}
                  subtitle={`${platformLabels[project.platform]} · ${
                    statusLabels[project.status]
                  }`}
                />
              ))
            )}
          </div>

          <div>
            <h3 style={styles.sectionTitle}>السكربتات</h3>
            {dashboard.scripts.length === 0 ? (
              <EmptyState text="لا توجد سكربتات حتى الآن." />
            ) : (
              dashboard.scripts.slice(0, 4).map((script) => (
                <CompactItem
                  key={script.id}
                  title={script.title}
                  subtitle={scriptStatusLabels[script.status]}
                />
              ))
            )}
          </div>
        </div>
      </section>
    </>
  );
}

function ProjectsView(props: {
  projects: EnterpriseProject[];
  busy: boolean;
  onCreate: () => Promise<void>;
  onStatus: (project: EnterpriseProject) => Promise<void>;
  onDelete: (project: EnterpriseProject) => Promise<void>;
}) {
  return (
    <section style={styles.panel}>
      <div style={styles.panelHeader}>
        <div>
          <div style={styles.eyebrow}>PROJECT MANAGEMENT</div>
          <h2 style={styles.panelTitle}>مشاريع المحتوى</h2>
        </div>

        <button
          style={styles.primaryButton}
          disabled={props.busy}
          onClick={() => void props.onCreate()}
        >
          ＋ إنشاء مشروع
        </button>
      </div>

      {props.projects.length === 0 ? (
        <EmptyState text="لا توجد مشاريع. أنشئ أول مشروع محتوى." />
      ) : (
        <div style={styles.cardsGrid}>
          {props.projects.map((project) => (
            <article key={project.id} style={styles.itemCard}>
              <div style={styles.cardTop}>
                <span style={styles.badge}>
                  {statusLabels[project.status]}
                </span>
                <span style={styles.platform}>
                  {platformLabels[project.platform]}
                </span>
              </div>

              <h3 style={styles.itemTitle}>{project.name}</h3>
              <p style={styles.itemDescription}>
                {project.description || "لا يوجد وصف للمشروع."}
              </p>

              <div style={styles.cardFooter}>
                <button
                  style={styles.secondaryButton}
                  disabled={props.busy}
                  onClick={() => void props.onStatus(project)}
                >
                  تغيير الحالة
                </button>

                <button
                  style={styles.dangerButton}
                  disabled={props.busy}
                  onClick={() => void props.onDelete(project)}
                >
                  حذف
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

function ScriptsView(props: {
  scripts: EnterpriseScript[];
  projects: EnterpriseProject[];
  busy: boolean;
  onCreate: () => Promise<void>;
  onEdit: (script: EnterpriseScript) => Promise<void>;
  onStatus: (script: EnterpriseScript) => Promise<void>;
}) {
  const projectName = (projectId: string) =>
    props.projects.find((project) => project.id === projectId)
      ?.name ?? "مشروع غير معروف";

  return (
    <section style={styles.panel}>
      <div style={styles.panelHeader}>
        <div>
          <div style={styles.eyebrow}>SCRIPT WORKSPACE</div>
          <h2 style={styles.panelTitle}>محرر السكربتات</h2>
        </div>

        <button
          style={styles.primaryButton}
          disabled={props.busy}
          onClick={() => void props.onCreate()}
        >
          ＋ إنشاء سكربت
        </button>
      </div>

      {props.scripts.length === 0 ? (
        <EmptyState text="لا توجد سكربتات. أنشئ أول سكربت." />
      ) : (
        <div style={styles.list}>
          {props.scripts.map((script) => (
            <article key={script.id} style={styles.scriptCard}>
              <div style={styles.cardTop}>
                <span style={styles.badge}>
                  {scriptStatusLabels[script.status]}
                </span>
                <span style={styles.platform}>
                  {projectName(script.projectId)}
                </span>
              </div>

              <h3 style={styles.itemTitle}>{script.title}</h3>
              <p style={styles.scriptPreview}>
                {script.content || "السكربت فارغ."}
              </p>

              <div style={styles.cardFooter}>
                <button
                  style={styles.primarySmallButton}
                  disabled={props.busy}
                  onClick={() => void props.onEdit(script)}
                >
                  تعديل السكربت
                </button>

                <button
                  style={styles.secondaryButton}
                  disabled={props.busy}
                  onClick={() => void props.onStatus(script)}
                >
                  تغيير المرحلة
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

function CalendarView(props: {
  items: EnterpriseCalendarItem[];
  projects: EnterpriseProject[];
  busy: boolean;
  onCreate: () => Promise<void>;
}) {
  const projectName = (projectId: string) =>
    props.projects.find((project) => project.id === projectId)
      ?.name ?? "مشروع غير معروف";

  return (
    <section style={styles.panel}>
      <div style={styles.panelHeader}>
        <div>
          <div style={styles.eyebrow}>CONTENT CALENDAR</div>
          <h2 style={styles.panelTitle}>تقويم المحتوى</h2>
        </div>

        <button
          style={styles.primaryButton}
          disabled={props.busy}
          onClick={() => void props.onCreate()}
        >
          ＋ جدولة محتوى
        </button>
      </div>

      {props.items.length === 0 ? (
        <EmptyState text="لا توجد عناصر مجدولة حتى الآن." />
      ) : (
        <div style={styles.list}>
          {props.items
            .slice()
            .sort(
              (a, b) =>
                Date.parse(a.scheduledAt) -
                Date.parse(b.scheduledAt),
            )
            .map((item) => (
              <article key={item.id} style={styles.calendarCard}>
                <div style={styles.calendarDate}>
                  <strong>
                    {new Date(item.scheduledAt).toLocaleDateString(
                      "ar-AE",
                      {
                        day: "2-digit",
                        month: "short",
                      },
                    )}
                  </strong>
                  <span>
                    {new Date(item.scheduledAt).toLocaleTimeString(
                      "ar-AE",
                      {
                        hour: "2-digit",
                        minute: "2-digit",
                      },
                    )}
                  </span>
                </div>

                <div style={{ flex: 1 }}>
                  <h3 style={styles.itemTitle}>{item.title}</h3>
                  <p style={styles.itemDescription}>
                    {projectName(item.projectId)} ·{" "}
                    {platformLabels[item.platform]}
                  </p>
                </div>

                <span style={styles.badge}>مجدول</span>
              </article>
            ))}
        </div>
      )}
    </section>
  );
}

function PromptsView(props: {
  prompts: EnterprisePrompt[];
  busy: boolean;
  onCreate: () => Promise<void>;
}) {
  const copyPrompt = async (prompt: string) => {
    await navigator.clipboard.writeText(prompt);
    window.alert("تم نسخ القالب.");
  };

  return (
    <section style={styles.panel}>
      <div style={styles.panelHeader}>
        <div>
          <div style={styles.eyebrow}>AI PROMPT LIBRARY</div>
          <h2 style={styles.panelTitle}>
            مكتبة القوالب الذكية
          </h2>
        </div>

        <button
          style={styles.primaryButton}
          disabled={props.busy}
          onClick={() => void props.onCreate()}
        >
          ＋ إضافة قالب
        </button>
      </div>

      {props.prompts.length === 0 ? (
        <EmptyState text="لا توجد قوالب ذكاء اصطناعي حتى الآن." />
      ) : (
        <div style={styles.cardsGrid}>
          {props.prompts.map((prompt) => (
            <article key={prompt.id} style={styles.itemCard}>
              <div style={styles.cardTop}>
                <span style={styles.badge}>AI Prompt</span>
                <span style={styles.platform}>✦ CreatorOS</span>
              </div>

              <h3 style={styles.itemTitle}>{prompt.name}</h3>
              <p style={styles.itemDescription}>
                {prompt.purpose || "قالب ذكاء اصطناعي"}
              </p>

              <div style={styles.promptText}>
                {prompt.prompt}
              </div>

              <button
                style={styles.primarySmallButton}
                onClick={() => void copyPrompt(prompt.prompt)}
              >
                نسخ القالب
              </button>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

function NavButton(props: {
  active: boolean;
  icon: string;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      style={{
        ...styles.navButton,
        ...(props.active ? styles.navButtonActive : {}),
      }}
      onClick={props.onClick}
    >
      <span style={styles.navIcon}>{props.icon}</span>
      <span>{props.label}</span>
    </button>
  );
}

function MetricCard(props: {
  icon: string;
  label: string;
  value: number;
  note: string;
}) {
  return (
    <article style={styles.metricCard}>
      <div style={styles.metricIcon}>{props.icon}</div>
      <div style={styles.metricValue}>{props.value}</div>
      <div style={styles.metricLabel}>{props.label}</div>
      <div style={styles.metricNote}>{props.note}</div>
    </article>
  );
}

function ActionButton(props: {
  icon: string;
  title: string;
  description: string;
  disabled: boolean;
  onClick: () => void;
}) {
  return (
    <button
      style={styles.actionButton}
      disabled={props.disabled}
      onClick={props.onClick}
    >
      <span style={styles.actionIcon}>{props.icon}</span>
      <span style={{ flex: 1 }}>
        <strong style={styles.actionTitle}>{props.title}</strong>
        <span style={styles.actionDescription}>
          {props.description}
        </span>
      </span>
      <span>←</span>
    </button>
  );
}

function SystemRow(props: {
  label: string;
  value: string;
}) {
  return (
    <div style={styles.systemRow}>
      <span>{props.label}</span>
      <strong style={styles.systemValue}>
        {props.value === "ready"
          ? "جاهز"
          : props.value === "persistent"
            ? "دائم"
            : props.value}
      </strong>
    </div>
  );
}

function EmptyState(props: { text: string }) {
  return (
    <div style={styles.emptyState}>
      <div style={styles.emptyIcon}>▣</div>
      <div>{props.text}</div>
    </div>
  );
}

function CompactItem(props: {
  title: string;
  subtitle: string;
}) {
  return (
    <div style={styles.compactItem}>
      <div style={styles.compactDot} />
      <div>
        <strong>{props.title}</strong>
        <div style={styles.mutedSmall}>{props.subtitle}</div>
      </div>
    </div>
  );
}

function selectPlatform(): EnterprisePlatform | null {
  const value = window.prompt(
    [
      "اختر المنصة:",
      "1 = YouTube",
      "2 = TikTok",
      "3 = YouTube + TikTok",
    ].join("\n"),
    "3",
  );

  if (value === "1") {
    return "YouTube";
  }

  if (value === "2") {
    return "TikTok";
  }

  if (value === "3") {
    return "Both";
  }

  return null;
}

function selectProject(
  projects: EnterpriseProject[],
): EnterpriseProject | null {
  const options = projects
    .map(
      (project, index) =>
        `${index + 1} = ${project.name}`,
    )
    .join("\n");

  const value = window.prompt(
    `اختر المشروع:\n${options}`,
    "1",
  );

  if (!value) {
    return null;
  }

  const index = Number(value) - 1;

  if (
    !Number.isInteger(index) ||
    index < 0 ||
    index >= projects.length
  ) {
    return null;
  }

  return projects[index];
}

const styles: Record<string, React.CSSProperties> = {
  app: {
    minHeight: "100vh",
    display: "flex",
    background:
      "radial-gradient(circle at top right, #172039 0%, #090d17 42%, #05070d 100%)",
    color: "#f4f7ff",
    fontFamily:
      '"Segoe UI", Tahoma, Arial, sans-serif',
  },
  sidebar: {
    width: 270,
    minHeight: "100vh",
    padding: "28px 20px",
    boxSizing: "border-box",
    background: "rgba(6, 9, 17, 0.94)",
    borderLeft: "1px solid rgba(255,255,255,0.08)",
    position: "sticky",
    top: 0,
    alignSelf: "flex-start",
  },
  brand: {
    display: "flex",
    alignItems: "center",
    gap: 14,
    marginBottom: 38,
  },
  logo: {
    width: 48,
    height: 48,
    borderRadius: 15,
    display: "grid",
    placeItems: "center",
    background:
      "linear-gradient(135deg, #7c5cff, #3cc7ff)",
    fontSize: 24,
    fontWeight: 800,
    boxShadow: "0 12px 34px rgba(73,115,255,0.35)",
  },
  brandName: {
    display: "block",
    fontSize: 21,
  },
  brandSubtitle: {
    marginTop: 4,
    color: "#7f8ca8",
    fontSize: 9,
    letterSpacing: 1.4,
  },
  nav: {
    display: "grid",
    gap: 8,
  },
  navButton: {
    width: "100%",
    border: 0,
    borderRadius: 13,
    padding: "13px 14px",
    display: "flex",
    alignItems: "center",
    gap: 12,
    background: "transparent",
    color: "#9aa7c2",
    cursor: "pointer",
    textAlign: "right",
    fontSize: 14,
  },
  navButtonActive: {
    color: "#ffffff",
    background:
      "linear-gradient(90deg, rgba(93,77,255,0.24), rgba(51,186,255,0.08))",
    border: "1px solid rgba(105,114,255,0.28)",
  },
  navIcon: {
    width: 25,
    fontSize: 18,
    textAlign: "center",
  },
  connectionBox: {
    marginTop: 40,
    padding: 15,
    display: "flex",
    gap: 10,
    alignItems: "center",
    borderRadius: 14,
    background: "rgba(255,255,255,0.035)",
    border: "1px solid rgba(255,255,255,0.07)",
    fontSize: 12,
  },
  connectionDot: {
    width: 10,
    height: 10,
    borderRadius: "50%",
    boxShadow: "0 0 14px currentColor",
  },
  main: {
    flex: 1,
    minWidth: 0,
    padding: "34px",
    boxSizing: "border-box",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 20,
    marginBottom: 26,
  },
  eyebrow: {
    color: "#7e8ca8",
    fontSize: 10,
    letterSpacing: 2,
    fontWeight: 700,
  },
  title: {
    fontSize: 31,
    margin: "8px 0 7px",
  },
  subtitle: {
    margin: 0,
    color: "#8e9bb6",
    fontSize: 14,
  },
  refreshButton: {
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 12,
    padding: "11px 17px",
    background: "rgba(255,255,255,0.045)",
    color: "#ffffff",
    cursor: "pointer",
  },
  primaryButton: {
    border: 0,
    borderRadius: 12,
    padding: "12px 18px",
    background:
      "linear-gradient(135deg, #7359ff, #3eb9ff)",
    color: "#ffffff",
    fontWeight: 700,
    cursor: "pointer",
  },
  primarySmallButton: {
    border: 0,
    borderRadius: 10,
    padding: "9px 13px",
    background:
      "linear-gradient(135deg, #7359ff, #3eb9ff)",
    color: "#ffffff",
    cursor: "pointer",
  },
  secondaryButton: {
    border: "1px solid rgba(255,255,255,0.13)",
    borderRadius: 10,
    padding: "9px 13px",
    background: "rgba(255,255,255,0.04)",
    color: "#dfe6f7",
    cursor: "pointer",
  },
  dangerButton: {
    border: "1px solid rgba(255,93,115,0.27)",
    borderRadius: 10,
    padding: "9px 13px",
    background: "rgba(255,93,115,0.09)",
    color: "#ff7d91",
    cursor: "pointer",
  },
  metricsGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(auto-fit, minmax(190px, 1fr))",
    gap: 16,
    marginBottom: 18,
  },
  metricCard: {
    padding: 20,
    borderRadius: 17,
    background:
      "linear-gradient(145deg, rgba(25,33,55,0.92), rgba(12,17,30,0.94))",
    border: "1px solid rgba(255,255,255,0.08)",
    boxShadow: "0 20px 45px rgba(0,0,0,0.18)",
  },
  metricIcon: {
    width: 37,
    height: 37,
    borderRadius: 11,
    display: "grid",
    placeItems: "center",
    background: "rgba(100,91,255,0.18)",
    color: "#a99cff",
    marginBottom: 14,
  },
  metricValue: {
    fontSize: 29,
    fontWeight: 800,
  },
  metricLabel: {
    fontWeight: 700,
    marginTop: 3,
  },
  metricNote: {
    color: "#77849e",
    fontSize: 11,
    marginTop: 8,
  },
  twoColumns: {
    display: "grid",
    gridTemplateColumns:
      "minmax(0, 1.7fr) minmax(280px, 1fr)",
    gap: 18,
    marginBottom: 18,
  },
  panel: {
    padding: 22,
    borderRadius: 18,
    background: "rgba(13,18,31,0.88)",
    border: "1px solid rgba(255,255,255,0.075)",
    boxShadow: "0 20px 50px rgba(0,0,0,0.16)",
    marginBottom: 18,
  },
  panelHeader: {
    display: "flex",
    justifyContent: "space-between",
    gap: 20,
    alignItems: "center",
    marginBottom: 19,
  },
  panelTitle: {
    margin: "7px 0 0",
    fontSize: 20,
  },
  actionsGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(auto-fit, minmax(230px, 1fr))",
    gap: 10,
  },
  actionButton: {
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 13,
    padding: 14,
    display: "flex",
    alignItems: "center",
    gap: 12,
    textAlign: "right",
    background: "rgba(255,255,255,0.025)",
    color: "#ffffff",
    cursor: "pointer",
  },
  actionIcon: {
    width: 37,
    height: 37,
    borderRadius: 10,
    display: "grid",
    placeItems: "center",
    background: "rgba(88,107,255,0.15)",
    color: "#9ca8ff",
    fontSize: 19,
  },
  actionTitle: {
    display: "block",
  },
  actionDescription: {
    display: "block",
    marginTop: 4,
    color: "#78859f",
    fontSize: 11,
  },
  systemRow: {
    display: "flex",
    justifyContent: "space-between",
    padding: "13px 0",
    borderBottom: "1px solid rgba(255,255,255,0.06)",
    color: "#aeb8cd",
    fontSize: 13,
  },
  systemValue: {
    color: "#4ce4a6",
  },
  workspaceGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(auto-fit, minmax(280px, 1fr))",
    gap: 22,
  },
  sectionTitle: {
    fontSize: 14,
    color: "#cfd7e9",
    marginBottom: 12,
  },
  compactItem: {
    display: "flex",
    gap: 10,
    alignItems: "center",
    padding: "11px 0",
    borderBottom: "1px solid rgba(255,255,255,0.05)",
    fontSize: 13,
  },
  compactDot: {
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: "#745eff",
  },
  mutedSmall: {
    color: "#77849d",
    fontSize: 10,
    marginTop: 4,
  },
  cardsGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(auto-fill, minmax(270px, 1fr))",
    gap: 15,
  },
  itemCard: {
    padding: 18,
    borderRadius: 15,
    background: "rgba(255,255,255,0.028)",
    border: "1px solid rgba(255,255,255,0.075)",
  },
  cardTop: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 10,
    marginBottom: 14,
  },
  badge: {
    padding: "5px 9px",
    borderRadius: 999,
    background: "rgba(83,215,163,0.12)",
    color: "#58dfa8",
    fontSize: 10,
    fontWeight: 700,
  },
  platform: {
    color: "#7f8ca6",
    fontSize: 10,
  },
  itemTitle: {
    margin: "0 0 8px",
    fontSize: 17,
  },
  itemDescription: {
    color: "#8793ac",
    lineHeight: 1.7,
    fontSize: 12,
    minHeight: 20,
  },
  cardFooter: {
    display: "flex",
    gap: 8,
    flexWrap: "wrap",
    marginTop: 16,
  },
  list: {
    display: "grid",
    gap: 12,
  },
  scriptCard: {
    padding: 18,
    borderRadius: 15,
    background: "rgba(255,255,255,0.028)",
    border: "1px solid rgba(255,255,255,0.075)",
  },
  scriptPreview: {
    whiteSpace: "pre-wrap",
    color: "#929db5",
    lineHeight: 1.8,
    fontSize: 12,
    maxHeight: 110,
    overflow: "hidden",
  },
  calendarCard: {
    padding: 15,
    borderRadius: 14,
    display: "flex",
    gap: 15,
    alignItems: "center",
    background: "rgba(255,255,255,0.028)",
    border: "1px solid rgba(255,255,255,0.075)",
  },
  calendarDate: {
    minWidth: 74,
    padding: 10,
    borderRadius: 12,
    display: "grid",
    gap: 4,
    textAlign: "center",
    background: "rgba(101,87,255,0.13)",
    color: "#bbb4ff",
    fontSize: 11,
  },
  promptText: {
    padding: 12,
    marginTop: 13,
    marginBottom: 14,
    borderRadius: 11,
    background: "rgba(0,0,0,0.2)",
    color: "#b6c0d6",
    fontSize: 11,
    lineHeight: 1.8,
    whiteSpace: "pre-wrap",
  },
  emptyState: {
    minHeight: 180,
    display: "grid",
    placeItems: "center",
    alignContent: "center",
    gap: 13,
    color: "#74819b",
    textAlign: "center",
  },
  emptyIcon: {
    fontSize: 35,
    color: "#5f6b86",
  },
  successMessage: {
    padding: 13,
    marginBottom: 16,
    borderRadius: 12,
    background: "rgba(56,214,151,0.1)",
    border: "1px solid rgba(56,214,151,0.25)",
    color: "#58dfa8",
  },
  errorMessage: {
    padding: 13,
    marginBottom: 16,
    borderRadius: 12,
    background: "rgba(255,85,111,0.09)",
    border: "1px solid rgba(255,85,111,0.24)",
    color: "#ff8397",
  },
  loading: {
    minHeight: 400,
    display: "grid",
    placeItems: "center",
    color: "#8f9bb4",
  },
};

export default App;